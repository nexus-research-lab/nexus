// 本文件验证锁存在时间不能替代持有者退出证据。
package autodream

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestConsolidationLockPreservesLiveOrUnknownHolder 老锁也可能仍在使用；不明内容或不可探测身份保持占用。
func TestConsolidationLockPreservesLiveOrUnknownHolder(t *testing.T) {
	for _, scenario := range []string{"live", "same_process", "unknown_probe", "invalid", "partial"} {
		t.Run(scenario, func(t *testing.T) {
			root := t.TempDir()
			content := "12345\n"
			processID := 67890
			probe := func(int) bool { return true }
			switch scenario {
			case "same_process":
				processID = 12345
				probe = func(int) bool { t.Fatal("same holder must not be probed"); return false }
			case "unknown_probe":
				probe = nil
			case "invalid":
				content = "invalid-holder\n"
			case "partial":
				content = ""
			}
			path := activeLockPath(root)
			if err := os.WriteFile(path, []byte(content), 0600); err != nil {
				t.Fatal(err)
			}
			old := time.Now().Add(-48 * time.Hour)
			if err := os.Chtimes(path, old, old); err != nil {
				t.Fatal(err)
			}
			acquired, err := TryAcquireConsolidationLock(root, time.Now(), processID, probe)
			if err != nil || acquired {
				t.Fatalf("uncertain/live lock was stolen: acquired=%t err=%v", acquired, err)
			}
			got, err := os.ReadFile(path)
			if err != nil || string(got) != content {
				t.Fatalf("holder state changed: %q err=%v", got, err)
			}
			if _, err := os.Stat(filepath.Join(root, completionFileName)); !os.IsNotExist(err) {
				t.Fatalf("unsuccessful acquisition changed completion: %v", err)
			}
		})
	}
}

// TestConsolidationLockReclaimsConfirmedDeadHolder 保留显式判定死亡后的既有恢复路径。
func TestConsolidationLockReclaimsConfirmedDeadHolder(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(activeLockPath(root), []byte("12345\n"), 0600); err != nil {
		t.Fatal(err)
	}
	probed := 0
	acquired, err := TryAcquireConsolidationLock(root, time.Now(), 67890, func(pid int) bool {
		probed = pid
		return false
	})
	if err != nil || !acquired || probed != 12345 {
		t.Fatalf("confirmed dead holder not reclaimed: acquired=%t probe=%d err=%v", acquired, probed, err)
	}
}
