//go:build darwin

// INPUT: 原生文件沙箱、AutoDream 完成标记和历史会话目录。
// OUTPUT: 拒绝的元数据不能推动后台任务，失败扫描不占用扫描节流窗口。
// POS: AutoDream 读取入口回归；写入锁和完成标记另行验收。
package runtime

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	delegation "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/agent"
	coresession "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/session"
	"github.com/nexus-research-lab/nexus-agent-sdk-go/sandbox"
)

// TestDarwinSandboxAutoDreamScan 检查元数据读取拒绝、链接拒绝及正常历史会话发现。
func TestDarwinSandboxAutoDreamScan(t *testing.T) {
	for _, source := range []string{"completion", "completion_symlink", "directory", "transcript", "transcript_symlink", "allowed", "missing"} {
		t.Run(source, func(t *testing.T) {
			cfg := contextFileFixture(t)
			cfg.Session.DisablePersistence = false
			cfg.Env["NEXUS_DISABLE_AUTO_MEMORY"] = ""
			cfg.Env["NEXUS_ENABLE_AUTO_DREAM"] = "1"
			cfg.Tools.Permission.Sandbox.Resources.WriteScope = sandbox.WriteScopeWorkspaceWrite
			policy := &sandbox.FilesystemConfig{}
			cfg.Tools.Permission.Sandbox.Filesystem = policy
			completion := filepath.Join(cfg.Project.CWD, "memory", ".consolidated-at")
			completionTarget := completion
			if source == "completion_symlink" {
				completionTarget = filepath.Join(t.TempDir(), "completion")
			}
			writeContextFixture(t, completionTarget, "fixture\n")
			old := time.Now().Add(-48 * time.Hour)
			if err := os.Chtimes(completionTarget, old, old); err != nil {
				t.Fatal(err)
			}
			if source == "completion_symlink" {
				if err := os.MkdirAll(filepath.Dir(completion), 0700); err != nil {
					t.Fatal(err)
				}
				if err := os.Symlink(completionTarget, completion); err != nil {
					t.Fatal(err)
				}
			}
			transcripts := coresession.ProjectDir(cfg.ConfigDir, cfg.Project.CWD)
			for index := 0; index < 5 && source != "missing"; index++ {
				file := filepath.Join(transcripts, fmt.Sprintf("history-%d.jsonl", index))
				if source == "transcript_symlink" && index == 0 {
					target := filepath.Join(t.TempDir(), "private-history.jsonl")
					writeContextFixture(t, target, "{}\n")
					if err := os.MkdirAll(transcripts, 0700); err != nil {
						t.Fatal(err)
					}
					if err := os.Symlink(target, file); err != nil {
						t.Fatal(err)
					}
					policy.DenyRead = []string{target}
				} else {
					writeContextFixture(t, file, "{}\n")
				}
				if source == "transcript" && index == 0 {
					policy.DenyRead = []string{file}
				}
			}
			switch source {
			case "completion", "completion_symlink":
				policy.DenyRead = []string{completionTarget}
			case "directory":
				policy.DenyRead = []string{transcripts}
			}
			called := false
			stop := errors.New("stop after verifying the scan")
			cfg.Tools.Agent.Runner = func(_ context.Context, _ delegation.AgentRunRequest) (delegation.AgentRunResult, error) {
				called = true
				return delegation.AgentRunResult{}, stop
			}
			rt, err := New(cfg)
			if err != nil {
				t.Fatal(err)
			}
			result, err := rt.TryAutoDream(t.Context())
			switch source {
			case "allowed":
				if !called || !errors.Is(err, stop) || result.Reason != "execution_failed" {
					t.Fatalf("allowed scan: called=%t result=%#v err=%v", called, result, err)
				}
			case "missing":
				if called || err != nil || result.Reason != "session_gate" {
					t.Fatalf("absent history: called=%t result=%#v err=%v", called, result, err)
				}
			default:
				if called || err == nil || rt.autoDream.lastScanMS != 0 {
					t.Fatalf("denied scan: called=%t result=%#v err=%v scan=%d", called, result, err, rt.autoDream.lastScanMS)
				}
			}
		})
	}
}
