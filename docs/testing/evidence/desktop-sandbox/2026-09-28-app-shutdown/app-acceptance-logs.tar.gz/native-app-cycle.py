import pathlib,json,subprocess,os,time,re,urllib.request,sqlite3,signal,datetime
ptr=pathlib.Path('/tmp/nexus-current-recovery-acceptance.json');p=json.loads(ptr.read_text());root=pathlib.Path(p['root']);state=pathlib.Path(p['stateRoot']);conv=json.loads((root/'test-conversation.json').read_text());key='agent:'+conv['sessions'][0]['agent_id']+':ws:dm:'+conv['conversation']['id']
def receipts():
 db=sqlite3.connect('file:'+str(state/'app/data/nexus.db')+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 rows=[dict(x) for x in db.execute('select session_key,generation,runtime_kind,phase,unknown_reason,session_id,lease_id,resource_policy_json from sandbox_policy_receipts where session_key=? order by generation',(key,))];db.close();return rows
before=receipts();expected=p['app']+'/Contents/MacOS/Nexus'
assert subprocess.check_output(['ps','-p',str(p['appPID']),'-o','comm='],text=True).strip()==expected
psrows=subprocess.check_output(['ps','-ax','-o','pid=,ppid=,comm='],text=True).splitlines();rows=[x.strip().split(None,2) for x in psrows];ids={p['appPID']}
for _ in range(12):ids.update(int(pid) for pid,ppid,cmd in rows if int(ppid) in ids)
start=time.monotonic();os.kill(p['appPID'],signal.SIGTERM)
for _ in range(80):
 alive=subprocess.run(['ps','-p',','.join(str(i) for i in sorted(ids)),'-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
 if not alive:break
 time.sleep(.25)
after=receipts();ev={'source':p['source'],'scope':'native-app-through-websocket','trigger':'SIGTERM handled by NSApp.terminate','sessionKey':key,'before':before,'after':after,'oldProcessIDs':sorted(ids),'remainingOldProcesses':alive,'shutdownSeconds':time.monotonic()-start,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'app-restart-evidence.json').write_text(json.dumps(ev,indent=2));print(json.dumps(ev))
assert not alive,'test processes remained'
assert after and after[-1]['phase']=='retired','normal exit left receipt unresolved'
env={k:os.environ[k] for k in ['PATH','HOME','USER','LOGNAME','TMPDIR','LANG'] if k in os.environ};env.update(NEXUS_DESKTOP_STATE_ROOT=str(state),NEXUS_DESKTOP_PREFERENCES_SUITE=p['bundleID'],NEXUS_DESKTOP_KEYCHAIN_MODE='file',NEXUS_DESKTOP_DISABLE_UPDATE_CHECK='1')
with (root/'app-api-acceptance-restart.log').open('ab') as log:app=subprocess.Popen([expected],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
p['appPID']=app.pid;ptr.write_text(json.dumps(p))
for _ in range(60):
 for child in subprocess.run(['pgrep','-P',str(app.pid)],capture_output=True,text=True).stdout.split():
  cmd=subprocess.run(['ps','-p',child,'-o','comm='],capture_output=True,text=True).stdout.strip()
  if cmd!=p['app']+'/Contents/MacOS/nexus-server':continue
  raw=subprocess.check_output(['ps','eww','-p',child,'-o','command='],text=True);assert 'NEXUS_STATE_ROOT='+str(state) in raw
  tok=re.search(r'NEXUS_DESKTOP_SESSION_TOKEN=([a-f0-9]{64})',raw);port=re.search(r'\bPORT=(\d+)\b',raw)
  if not tok or not port:continue
  conn={'base':'http://127.0.0.1:'+port.group(1)+'/nexus/v1','token':tok.group(1)};file=root/'test-connection.json';file.write_text(json.dumps(conn));file.chmod(0o600)
  try:
   req=urllib.request.Request(conn['base']+'/agents',headers={'X-Nexus-Desktop-Token':conn['token']});r=json.load(urllib.request.urlopen(req,timeout=2));print({'restartedPID':app.pid,'healthy':r.get('code')=='0000'});raise SystemExit(0)
  except urllib.error.URLError:pass
 time.sleep(.25)
raise RuntimeError('test App failed restart')
