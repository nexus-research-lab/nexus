const fs = require('node:fs');
const {createRequire}=require('node:module');
const requireWeb=createRequire('/Users/berhand/program/Work/Nexus/worktrees/nexus/desktop-sandbox/web/package.json');
const WebSocket=requireWeb('ws');
const {randomUUID}=require('node:crypto');
const p=JSON.parse(fs.readFileSync('/tmp/nexus-current-recovery-acceptance.json','utf8'));
const c=JSON.parse(fs.readFileSync(p.root+'/test-connection.json','utf8'));
const r=JSON.parse(fs.readFileSync(p.root+'/test-conversation.json','utf8'));
const key=`agent:${r.sessions[0].agent_id}:ws:dm:${r.conversation.id}`;
const suffix=process.argv[2]||'before';
const events=[];
const requestId=randomUUID();
const ws=new WebSocket(c.base.replace(/^http/,'ws')+'/chat/ws',{headers:{'X-Nexus-Desktop-Token':c.token},origin:new URL(c.base).origin});
const deadline=setTimeout(()=>{console.error('test round timed out');ws.terminate();process.exitCode=1},150000);
ws.on('open',()=>{
 ws.send(JSON.stringify({type:'bind_session',session_key:key,agent_id:r.sessions[0].agent_id}));
 ws.send(JSON.stringify({type:'chat',session_key:key,agent_id:r.sessions[0].agent_id,content:'这是独立 App 测试。仅使用 Read 读取当前工作区已存在的 sandbox-ui-qa.txt，回复读取到的原内容即可。不要写文件，不要联网，不要调用 deliver_files 或任何其他工具。',client_request_id:requestId,client_message_id:randomUUID()}));
});
ws.on('message',raw=>{
 const e=JSON.parse(raw);events.push(e);
 if(['chat_ack','round_status','permission_request','error'].includes(e.event_type))console.log(JSON.stringify({event_type:e.event_type,session_key:e.session_key,data:e.data}));
 if(e.event_type==='permission_request'){
  clearTimeout(deadline);fs.writeFileSync(p.root+`/chat-${suffix}-events.json`,JSON.stringify(events,null,2));console.error('Unexpected approval; no automatic widening');ws.close();process.exitCode=1;
 }
 if(e.event_type==='round_status' && e.data.status!=='running'){
  clearTimeout(deadline);fs.writeFileSync(p.root+`/chat-${suffix}-events.json`,JSON.stringify(events,null,2));ws.close();if(e.data.status!=='finished')process.exitCode=1;
 }
});
ws.on('error',()=>{console.error('test websocket failed');process.exitCode=1;clearTimeout(deadline)});
ws.on('close',()=>clearTimeout(deadline));
