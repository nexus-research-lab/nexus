//go:build darwin

// 原生回归夹具：被拒绝的后台会话替换记录不能被宿主读取或回退带入。
package runtime

import (
 "fmt"
 "os"
 "path/filepath"
 "testing"
 coresession "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/session"
 "github.com/nexus-research-lab/nexus-agent-sdk-go/sandbox"
)

func TestDarwinSandboxMemoryTranscriptReplacements(t *testing.T) {
 for _, source := range []string{"direct_denied", "symlink_denied", "allowed"} {
  t.Run(source, func(t *testing.T) {
   cfg := contextFileFixture(t)
   sessionID := "ebf49e1d-f853-4f2a-b331-8b0e71584d71"
   cfg.Session.SessionID = sessionID
   transcript := filepath.Join(coresession.ProjectDir(cfg.ConfigDir, cfg.Project.CWD),sessionID+".jsonl")
   target := transcript
   if source == "symlink_denied" {target = filepath.Join(t.TempDir(),"private.jsonl")}
   content := fmt.Sprintf("{\"type\":\"content-replacement\",\"sessionId\":%q,\"replacements\":[{\"toolUseId\":\"protected-record\"}]}\n",sessionID)
   writeContextFixture(t,target,content)
   if source == "symlink_denied" {
    if err := os.MkdirAll(filepath.Dir(transcript),0700); err != nil {t.Fatal(err)}
    if err := os.Symlink(target,transcript); err != nil {t.Fatal(err)}
   }
   if source != "allowed" {cfg.Tools.Permission.Sandbox.Filesystem = &sandbox.FilesystemConfig{DenyRead:[]string{target}}}
   rt,err := New(cfg); if err != nil {t.Fatal(err)}
   if rt.session.TranscriptPath() != transcript {t.Fatalf("fixture path mismatch: %s vs %s",rt.session.TranscriptPath(),transcript)}
   got := rt.currentContentReplacementRecords(sessionID)
   if source == "allowed" {
    if len(got) != 1 {t.Fatalf("allowed records lost: %#v",got)}
   } else if len(got) != 0 {t.Fatalf("denied replacement escaped file policy: %#v",got)}
  })
 }
}
