//go:build darwin

// INPUT: 原生文件沙箱、禁止初始化写入的路径，以及既有摘要和模板。
// OUTPUT: 初始化不能绕过写入边界，摘要拒绝时不进入模型；只读会话保持可用。
// POS: 后台记忆原生 IO 回归，夹具只使用隔离目录与固定文本。
package runtime

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	delegation "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/agent"
	"github.com/nexus-research-lab/nexus-agent-sdk-go/internal/memory/summary"
	"github.com/nexus-research-lab/nexus-agent-sdk-go/sandbox"
)

// TestDarwinSandboxMemoryInitialization 普通 workspace 与显式根链接都必须拒绝禁止写入。
func TestDarwinSandboxMemoryInitialization(t *testing.T) {
	for _, source := range []string{"directory", "index", "root_symlink"} {
		t.Run(source, func(t *testing.T) {
			cfg := contextFileFixture(t)
			cfg.Session.DisablePersistence = false
			cfg.Env["NEXUS_DISABLE_AUTO_MEMORY"] = ""
			cfg.Tools.Permission.Sandbox.Resources.WriteScope = sandbox.WriteScopeWorkspaceWrite
			root := cfg.Project.CWD
			if source == "root_symlink" {
				target := t.TempDir()
				link := filepath.Join(root, "memory-root")
				if err := os.Symlink(target, link); err != nil {
					t.Fatal(err)
				}
				cfg.Env["NEXUS_MEMORY_DIR"] = link
				root = target
			}
			denied := filepath.Join(root, "memory")
			if source == "index" {
				denied = filepath.Join(root, "MEMORY.md")
			}
			cfg.Tools.Permission.Sandbox.Filesystem = &sandbox.FilesystemConfig{DenyWrite: []string{denied}}
			_, err := New(cfg)
			if err == nil {
				t.Error("denied initialization succeeded")
			}
			if _, statErr := os.Stat(denied); !os.IsNotExist(statErr) {
				t.Fatalf("denied initialization created %s: %v", source, statErr)
			}
		})
	}
}

// TestDarwinSandboxReadOnlyMemory 只读会话不在启动时创建记忆布局，也不启动后台写入。
func TestDarwinSandboxReadOnlyMemory(t *testing.T) {
	cfg := contextFileFixture(t)
	cfg.Session.DisablePersistence = false
	cfg.Env["NEXUS_DISABLE_AUTO_MEMORY"] = ""
	cfg.Env["NEXUS_ENABLE_AUTO_MEMORY_EXTRACTION"] = "1"
	cfg.Env[envEnableSessionSummary] = "1"
	cfg.Env["NEXUS_ENABLE_AUTO_DREAM"] = "1"
	rt, err := New(cfg)
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"memory", "MEMORY.md"} {
		if _, err := os.Stat(filepath.Join(cfg.Project.CWD, name)); !os.IsNotExist(err) {
			t.Errorf("read-only startup created %s: %v", name, err)
		}
	}
	if rt.autoMemoryExtractionEnabled() || rt.sessionSummaryExtractionEnabled() || rt.autoDreamGateOpen() {
		t.Error("read-only runtime schedules persistent memory writes")
	}
	if !strings.Contains(rt.autoMemoryPrompt(), "This session is read-only") {
		t.Error("read-only memory prompt missing")
	}
}

// TestDarwinSandboxSummaryCompaction 真实 compact 入口不能直接读取被拒绝的摘要。
func TestDarwinSandboxSummaryCompaction(t *testing.T) {
	for _, allowed := range []bool{false, true} {
		name := "denied"
		if allowed {
			name = "allowed"
		}
		t.Run(name, func(t *testing.T) {
			cfg := contextFileFixture(t)
			cfg.Session.DisablePersistence = false
			path := summary.Path(cfg.ConfigDir, cfg.Project.CWD, "summary-session")
			writeContextFixture(t, path, "PRIVATE_SUMMARY_BODY")
			if !allowed {
				cfg.Tools.Permission.Sandbox.Filesystem = &sandbox.FilesystemConfig{DenyRead: []string{path}}
			}
			rt, err := New(cfg)
			if err != nil {
				t.Fatal(err)
			}
			result := rt.querySessionSummaryCompaction(t.Context(), "summary-session")
			if allowed {
				if result == nil || result.Content != "PRIVATE_SUMMARY_BODY" {
					t.Fatalf("allowed summary missing: %#v", result)
				}
			} else if result != nil {
				t.Fatal("denied summary reached compact")
			}
		})
	}
}

// TestDarwinSandboxSummaryPreparation 覆盖摘要/模板/提示词拒绝、外链以及正常旧摘要更新。
func TestDarwinSandboxSummaryPreparation(t *testing.T) {
	for _, source := range []string{"summary", "template", "prompt", "write", "symlink", "allowed"} {
		t.Run(source, func(t *testing.T) {
			cfg := contextFileFixture(t)
			cfg.Session.DisablePersistence = false
			cfg.Tools.Permission.Sandbox.Resources.WriteScope = sandbox.WriteScopeWorkspaceWrite
			policy := &sandbox.FilesystemConfig{AllowWrite: []string{cfg.ConfigDir}}
			cfg.Tools.Permission.Sandbox.Filesystem = policy
			path := summary.Path(cfg.ConfigDir, cfg.Project.CWD, "summary-session")
			if source == "summary" || source == "allowed" || source == "prompt" {
				writeContextFixture(t, path, "EXISTING_SUMMARY_BODY")
			}
			switch source {
			case "summary":
				policy.DenyRead = []string{path}
			case "template", "prompt":
				custom := filepath.Join(cfg.ConfigDir, "session-memory", "config", source+".md")
				writeContextFixture(t, custom, "PRIVATE_CUSTOM_PROMPT {{currentNotes}}")
				policy.DenyRead = []string{custom}
			case "write":
				policy.DenyWrite = []string{path}
			case "symlink":
				target := filepath.Join(t.TempDir(), "denied-summary.md")
				writeContextFixture(t, target, "PRIVATE_LINKED_SUMMARY")
				if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
					t.Fatal(err)
				}
				if err := os.Symlink(target, path); err != nil {
					t.Fatal(err)
				}
				policy.DenyRead = []string{target}
			}
			rt, err := New(cfg)
			if err != nil {
				t.Fatal(err)
			}
			called := false
			err = rt.extractSessionSummary(t.Context(), func(_ context.Context, req delegation.AgentRunRequest) (delegation.AgentRunResult, error) {
				called = true
				if source != "allowed" {
					t.Error("denied summary preparation reached the model")
				}
				if !strings.Contains(req.Prompt, "EXISTING_SUMMARY_BODY") {
					t.Error("existing summary missing from allowed prompt")
				}
				return delegation.AgentRunResult{}, nil
			}, "summary-session", nil, summary.ExtractionDecision{})
			if source == "allowed" {
				if err != nil || !called {
					t.Fatalf("allowed preparation: called=%t err=%v", called, err)
				}
			} else if err == nil || called {
				t.Fatalf("denied preparation: called=%t err=%v", called, err)
			}
			if source == "write" {
				if _, err := os.Stat(path); !os.IsNotExist(err) {
					t.Fatalf("denied summary was created: %v", err)
				}
			}
			if source == "summary" || source == "allowed" || source == "prompt" {
				data, err := os.ReadFile(path)
				if err != nil || string(data) != "EXISTING_SUMMARY_BODY" {
					t.Fatalf("existing summary changed: %q %v", data, err)
				}
			}
		})
	}
}
