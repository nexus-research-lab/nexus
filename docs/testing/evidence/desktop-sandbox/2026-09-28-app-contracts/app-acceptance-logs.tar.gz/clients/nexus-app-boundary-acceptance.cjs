const x=require('/tmp/nexus-app-contract.cjs');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const assert=require('node:assert/strict');
(async()=>{
  const root=fs.mkdtempSync(path.join(os.homedir(),'nexus-sandbox-boundary-qa-'));
  fs.chmodSync(root,0o700);
  const checks=[];
  try {
    for(const [name,mode,allowed] of [['restricted','default',false],['full-access','bypassPermissions',true],['restricted-return','default',false]]){
      await x.settings(x.dmKey,mode);
      const file=path.join(root,name+'.txt');
      const command=`printf MACOS_MODE_BOUNDARY_QA > '${file}'`;
      const execution=allowed?'这是 Full Access 的显式单次沙箱外执行验收，Bash 参数必须设置 dangerouslyDisableSandbox=true，并等待本次审批。':'必须正常在当前权限模式执行，不要设置 dangerouslyDisableSandbox，也不要请求放宽权限。';
      const result=await x.round('boundary-'+name,{content:`这是新一次用户授权的隔离验收，只操作新建的测试目录；不要根据上一轮结果跳过本次调用。仅调用一次 Bash，command 严格为：${command}。${execution} 不要重试或改用其他工具。报告实际结果后结束。`,decision:'allow',expectedTool:'Bash',expectApproval:allowed,validateApproval:d=>d.permission_boundary===(allowed?'sandbox_escape':'tool') && d.tool_input?.command===command});
      x.checkTool(result,'Bash',{isError:!allowed});
      const exists=fs.existsSync(file);
      assert.equal(exists,allowed,`${name}: unexpected external write result`);
      if(allowed)assert.equal(fs.readFileSync(file,'utf8'),'MACOS_MODE_BOUNDARY_QA');
      checks.push({name,mode,allowed,file,exists,receipt:await x.receipt(x.dmKey),requestID:result.requestID,roundID:result.roundID,approvals:result.approvals});
      x.save('boundary-switch-evidence',checks);
      console.log(JSON.stringify({name,externalWrite:exists,expected:allowed}));
    }
  } finally {
    for(const name of ['restricted','full-access','restricted-return']){
      const file=path.join(root,name+'.txt');if(fs.existsSync(file))fs.unlinkSync(file);
    }
    fs.rmdirSync(root);
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
