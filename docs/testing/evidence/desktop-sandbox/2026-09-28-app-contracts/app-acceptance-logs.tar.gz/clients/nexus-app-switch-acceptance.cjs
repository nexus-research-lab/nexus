const x=require('/tmp/nexus-app-contract.cjs');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
(async()=>{
  const agent=await x.api('/agents/'+x.agentID);
  const canonical=fs.realpathSync(agent.workspace_path)+'/sandbox-ui-qa.txt';
  const content=`这是后端/权限切换验收。必须实际调用一次 Read，file_path 严格使用 ${canonical}，再回复真实内容。不要根据历史猜测，不要写入、联网、调用交付或其他工具。`;
  const checks=[];
  for(const [name,kind,mode] of [['fixed-nxs','nxs','default'],['fixed-claude','claude','default'],['fixed-nxs-return','nxs','default'],['fixed-full-access','nxs','bypassPermissions'],['fixed-restricted-return','nxs','default']]) {
    const prefs=await x.api('/settings/preferences');
    if(prefs.agent_runtime_kind!==kind)await x.api('/settings/preferences','PATCH',{agent_runtime_kind:kind},{'If-Match':`"preferences-${prefs.version}"`});
    const settings=await x.settings(x.dmKey,mode);
    const before=await x.receipt(x.dmKey);
    const result=await x.round(name,{content});
    x.checkTool(result,'Read',{contains:'MACOS_UI_QA_20260928_A'});
    const after=await x.receipt(x.dmKey);
    assert.equal(after.receipt.runtime_kind,kind);
    assert.equal(after.receipt.phase,'confirmed');
    const capabilities=after.receipt.required_capabilities;
    if(kind==='claude')assert.deepEqual(capabilities,['claude_native_sandbox']);
    else if(mode==='default')assert(capabilities.includes('sandbox_resources'));
    else assert(!capabilities.includes('sandbox_resources'));
    checks.push({name,kind,mode,settings,before,after,round:{requestID:result.requestID,roundID:result.roundID,approvals:result.approvals}});
    x.save('fixed-switch-evidence',checks);
    console.log(JSON.stringify({name,generation:after.receipt.generation,kind,mode,read:true,approvals:result.approvals}));
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
