// Isolated native App acceptance client. Connection data stays in the private fixture.
const fs = require('node:fs');
const {createRequire} = require('node:module');
const {randomUUID} = require('node:crypto');
const assert = require('node:assert/strict');
const WebSocket = createRequire('/Users/berhand/program/Work/Nexus/worktrees/nexus/desktop-sandbox/web/package.json')('ws');
const p = JSON.parse(fs.readFileSync('/tmp/nexus-current-recovery-acceptance.json','utf8'));
assert.equal(p.bundleID, 'com.nexus.sandbox-switch-qa');
const c = JSON.parse(fs.readFileSync(p.root+'/test-connection.json','utf8'));
const dm = JSON.parse(fs.readFileSync(p.root+'/test-conversation.json','utf8'));
const group = JSON.parse(fs.readFileSync(p.root+'/test-group.json','utf8'));
const agentID = dm.sessions[0].agent_id;
const dmKey = `agent:${agentID}:ws:dm:${dm.conversation.id}`;
const groupKey = `room:group:${group.conversation.id}`;
const groupRuntimeKey = `agent:${agentID}:ws:group:${group.conversation.id}`;
const save = (name,data) => fs.writeFileSync(p.root+'/'+name+'.json',JSON.stringify(data,null,2),{mode:0o600});
async function api(path, method='GET', body, extraHeaders={}) {
  const res = await fetch(c.base+path,{method,headers:{'X-Nexus-Desktop-Token':c.token,'Content-Type':'application/json',...extraHeaders},body:body === undefined ? undefined : JSON.stringify(body),signal:AbortSignal.timeout(30000)});
  const data = await res.json();
  if (!res.ok || data.code !== '0000') throw new Error(`HTTP ${method} ${path}: ${res.status} ${JSON.stringify(data)}`);
  return data.data;
}
async function settings(key,mode) {
  const path='/sessions/'+encodeURIComponent(key)+'/runtime-settings';
  const initial=await api(path);
  return api(path,'PUT',{...initial,permission_mode:mode});
}
const receipt = key => api('/settings/runtime/sandbox/receipt?session_key='+encodeURIComponent(key));
function scrub(value) {
  if (Array.isArray(value)) return value.map(scrub);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([k])=>!['thinking','signature'].includes(k)).map(([k,v])=>[k,scrub(v)]));
  return value;
}
async function round(name, {key=dmKey,content,decision,expectedTool,expectApproval=false,validateApproval}={}) {
  const events=[]; const answered=new Set(); const requestID=randomUUID(); let roundID; let approvals=0; let done=false;
  return new Promise((resolve,reject)=>{
    const ws=new WebSocket(c.base.replace(/^http/,'ws')+'/chat/ws',{headers:{'X-Nexus-Desktop-Token':c.token},origin:new URL(c.base).origin});
    const finish=(err)=>{
      if(done)return; done=true; clearTimeout(deadline); save('contract-'+name+'-events',scrub(events)); ws.close();
      if(err)reject(err);else {console.log(JSON.stringify({name,requestID,roundID,approvals,status:'finished'}));resolve({name,requestID,roundID,approvals,events});}
    };
    const deadline=setTimeout(()=>{
      if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'interrupt',session_key:key,round_id:roundID,client_request_id:randomUUID()}));
      finish(new Error(name+': timed out'));
    },150000);
    ws.on('open',()=>{
      if(key===groupKey)ws.send(JSON.stringify({type:'subscribe_room',room_id:group.room.id,conversation_id:group.conversation.id,last_seen_room_seq:0}));
      ws.send(JSON.stringify({type:'bind_session',session_key:key,agent_id:agentID}));
      ws.send(JSON.stringify({type:'chat',session_key:key,agent_id:agentID,content,client_request_id:requestID,client_message_id:randomUUID(),...(key===groupKey?{room_id:group.room.id,conversation_id:group.conversation.id,target_agent_ids:[agentID]}:{})}));
    });
    ws.on('message',raw=>{
      const e=JSON.parse(raw);events.push(e);
      if(e.event_type==='chat_ack' && e.data.client_request_id===requestID)roundID=e.data.round_id;
      if(e.event_type==='permission_request' && e.session_key===key) {
        if(!roundID || e.data.round_id!==roundID || answered.has(e.data.request_id))return;
        answered.add(e.data.request_id);
        const tool=e.data.tool_name;
        console.log(JSON.stringify({name,event:e.event_type,data:scrub(e.data)}));
        if(!decision || (expectedTool && tool!==expectedTool) || (validateApproval && !validateApproval(e.data))) {
          ws.send(JSON.stringify({type:'permission_response',session_key:key,request_id:e.data.request_id,decision:'deny'}));
          return finish(new Error(name+': unexpected approval '+tool));
        }
        approvals++;
        ws.send(JSON.stringify({type:'permission_response',session_key:key,request_id:e.data.request_id,decision}));
      }
      if(e.event_type==='error' && e.session_key===key) console.log(JSON.stringify({name,event:'error',data:e.data}));
      if(e.event_type==='round_status' && roundID && e.data.round_id===roundID && e.data.is_terminal) {
        if(e.data.status!=='finished')return finish(new Error(name+': round '+e.data.status));
        if(expectApproval && approvals===0)return finish(new Error(name+': expected approval absent'));
        finish();
      }
    });
    ws.on('error',()=>finish(new Error(name+': websocket failed')));
    ws.on('close',()=>{if(!done)finish(new Error(name+': socket closed before terminal'));});
  });
}
function checkTool(result,tool,{contains,isError=false}={}) {
  const blocks=result.events.filter(e=>e.round_id===result.roundID || e.data?.round_id===result.roundID).flatMap(e=>Array.isArray(e.data?.content)?e.data.content:[]);
  const ids=new Set(blocks.filter(b=>b.type==='tool_use' && b.name===tool).map(b=>b.id));
  assert(ids.size>0,`${result.name}: ${tool} was not called`);
  const outputs=blocks.filter(b=>b.type==='tool_result' && ids.has(b.tool_use_id));
  assert(outputs.some(b=>Boolean(b.is_error)===isError && (!contains || JSON.stringify(b.content).includes(contains))),`${result.name}: no matching ${tool} result`);
}
module.exports={p,c,dm,group,agentID,dmKey,groupKey,groupRuntimeKey,save,api,settings,receipt,round,checkTool};
