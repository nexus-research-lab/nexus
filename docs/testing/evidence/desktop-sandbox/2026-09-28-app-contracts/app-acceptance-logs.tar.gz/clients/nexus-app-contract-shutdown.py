import pathlib,json,subprocess,os,time,sqlite3,signal,datetime
p=json.load(open('/tmp/nexus-current-recovery-acceptance.json'));root=pathlib.Path(p['root']);state=pathlib.Path(p['stateRoot'])
assert p['bundleID']=='com.nexus.sandbox-switch-qa'
assert str(state).startswith('/var/folders/') and state.name=='state'
dm=json.load(open(root/'test-conversation.json'));group=json.load(open(root/'test-group.json'));agent=dm['sessions'][0]['agent_id']
keys=['agent:'+agent+':ws:dm:'+dm['conversation']['id'],'agent:'+agent+':ws:group:'+group['conversation']['id']]
background=root/'background-approval-evidence.json'
if background.exists(): keys.extend(x['started']['session_key'] for x in json.load(open(background)))
def receipts():
 db=sqlite3.connect('file:'+str(state/'app/data/nexus.db')+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 out=[]
 for k in keys:
  row=db.execute('select session_key,generation,runtime_kind,phase,unknown_reason,session_id,lease_id,resource_policy_json from sandbox_policy_receipts where session_key=? order by generation desc limit 1',(k,)).fetchone()
  if row:out.append(dict(row))
 db.close();return out
before=receipts();expected=p['app']+'/Contents/MacOS/Nexus'
assert subprocess.check_output(['ps','-p',str(p['appPID']),'-o','comm='],text=True).strip()==expected
raw=subprocess.check_output(['ps','-ax','-o','pid=,ppid=,comm='],text=True).splitlines();rows=[x.strip().split(None,2) for x in raw];ids={p['appPID']}
for _ in range(12):ids.update(int(pid) for pid,ppid,cmd in rows if int(ppid) in ids)
start=time.monotonic();os.kill(p['appPID'],signal.SIGTERM)
for _ in range(100):
 alive=subprocess.run(['ps','-p',','.join(str(i) for i in sorted(ids)),'-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
 if not alive:break
 time.sleep(.25)
after=receipts();scratch=[json.loads(x['resource_policy_json'])['scratch_root'] for x in after if x['resource_policy_json']]
ev={'source':p['source'],'sdk':p['sdk'],'scope':'native-app-through-websocket','trigger':'SIGTERM handled by NSApp.terminate','before':before,'after':after,'oldProcessIDs':sorted(ids),'remainingOldProcesses':alive,'scratch':[{'path':s,'exists':pathlib.Path(s).exists()} for s in sorted(set(scratch))],'shutdownSeconds':time.monotonic()-start,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'app-final-shutdown-evidence.json').write_text(json.dumps(ev,indent=2))
print(json.dumps({'source':p['source'],'remainingProcesses':bool(alive),'latestPhases':[x['phase'] for x in after],'scratchRemaining':any(x['exists'] for x in ev['scratch']),'shutdownSeconds':ev['shutdownSeconds']}))
assert not alive,'test processes remained'
assert len(after)==len(keys) and all(x['phase']=='retired' for x in after),'normal exit left latest receipt unresolved'
assert not any(x['exists'] for x in ev['scratch']),'scratch retained'
