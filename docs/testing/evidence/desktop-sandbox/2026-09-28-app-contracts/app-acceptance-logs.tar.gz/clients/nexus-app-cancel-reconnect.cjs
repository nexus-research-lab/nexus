const x=require('/tmp/nexus-app-contract.cjs');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {randomUUID}=require('node:crypto');
const {createRequire}=require('node:module');
const WebSocket=createRequire('/Users/berhand/program/Work/Nexus/worktrees/nexus/desktop-sandbox/web/package.json')('ws');
async function test(iteration){
  const agent=await x.api('/agents/'+x.agentID);
  const sentinel=agent.workspace_path+'/sandbox-pending-network-stop.txt';assert(!fs.existsSync(sentinel));
  const marker='MACOS_CANCEL_RECONNECT_'+randomUUID();
  const file=agent.workspace_path+'/sandbox-reconnect-read-'+iteration+'.txt';
  assert(!fs.existsSync(file));fs.writeFileSync(file,marker+'\n',{flag:'wx'});
  const command='/usr/bin/curl --head --silent --show-error --max-time 30 https://example.com && printf STOP_FAILED > sandbox-pending-network-stop.txt';
  const requestID=randomUUID(),interruptID=randomUUID(),events=[];let roundID,permissionID,terminal,lateRejected=false;
  await new Promise((resolve,reject)=>{
    const ws=new WebSocket(x.c.base.replace(/^http/,'ws')+'/chat/ws',{headers:{'X-Nexus-Desktop-Token':x.c.token},origin:new URL(x.c.base).origin});
    let done=false;
    const finish=(err)=>{if(done)return;done=true;clearTimeout(timer);ws.close();fs.writeFileSync(x.p.root+'/contract-cancel-reconnect-'+iteration+'-events.json',JSON.stringify(events,(k,v)=>['thinking','signature'].includes(k)?undefined:v,2));err?reject(err):resolve();};
    const timer=setTimeout(()=>finish(new Error('pending network cancellation timed out')),80000);
    ws.on('open',()=>{
      ws.send(JSON.stringify({type:'bind_session',session_key:x.dmKey,agent_id:x.agentID}));
      ws.send(JSON.stringify({type:'chat',session_key:x.dmKey,agent_id:x.agentID,client_request_id:requestID,client_message_id:randomUUID(),content:`这是新的待审批取消验收 ${iteration}。只用一次 Bash，command 严格为 ${command}。正常沙箱执行，不设置 dangerouslyDisableSandbox；等待本轮审批，不重试、不改用其他工具。`}));
    });
    ws.on('message',raw=>{
      const e=JSON.parse(raw);events.push(e);
      if(e.event_type==='chat_ack' && e.data.client_request_id===requestID)roundID=e.data.round_id;
      if(e.event_type==='permission_request' && roundID && e.data.round_id===roundID && !permissionID){
        if(e.data.permission_boundary!=='sandbox_network' || e.data.tool_input?.network_target?.host!=='example.com')return finish(new Error('unexpected permission'));
        permissionID=e.data.request_id;
        console.log(JSON.stringify({iteration,stage:'interrupt-pending-network',roundID,permissionID}));
        ws.send(JSON.stringify({type:'interrupt',session_key:x.dmKey,round_id:roundID,client_request_id:interruptID}));
      }
      if(e.event_type==='round_status' && e.data.round_id===roundID && e.data.is_terminal && !terminal){
        terminal=e.data;if(!permissionID)return finish(new Error('no pending permission to cancel'));
        ws.send(JSON.stringify({type:'permission_response',session_key:x.dmKey,request_id:permissionID,decision:'allow'}));
      }
      if(terminal && e.event_type==='error' && e.data.error_type==='permission_request_not_found'){lateRejected=true;finish();}
    });
    ws.on('error',()=>finish(new Error('websocket error')));
    ws.on('close',()=>{if(!done)finish(new Error('socket closed before cancellation evidence'))});
  });
  assert.equal(terminal.status,'interrupted');assert(lateRejected);assert(!fs.existsSync(sentinel));
  assert(events.some(e=>e.event_type==='permission_request_resolved' && e.data.request_id===permissionID && e.data.status==='cancelled'));
  // Deliberately reconnect without waiting for interrupt_ack or old-socket close.
  const result=await x.round('after-cancel-reconnect-'+iteration,{content:`这是紧随取消后的独立只读请求。请仅实际调用一次 Read 读取 ${file}，报告文件内容，不调用其他工具。`});
  x.checkTool(result,'Read',{contains:marker});
  const ev={source:x.p.source,iteration,requestID,interruptID,roundID,permissionID,terminal,lateRejected,sentinelExists:false,interruptACKObservedBeforeClose:events.some(e=>e.event_type==='interrupt_ack'),nextRound:{requestID:result.requestID,roundID:result.roundID,expectedMarker:marker},receipt:await x.receipt(x.dmKey)};
  fs.unlinkSync(file);console.log(JSON.stringify({iteration,cancelled:true,lateApprovalRejected:true,sentinelExists:false,nextReadPassed:true}));return ev;
}
(async()=>{const all=[];for(let i=1;i<=2;i++){all.push(await test(i));x.save('network-cancel-reconnect-evidence',all)}})().catch(e=>{console.error(e.message);process.exitCode=1});
