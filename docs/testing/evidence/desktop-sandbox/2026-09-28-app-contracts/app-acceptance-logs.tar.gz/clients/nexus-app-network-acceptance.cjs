const x=require('/tmp/nexus-app-contract.cjs');
const assert=require('node:assert/strict');
(async()=>{
  await x.settings(x.dmKey,'default');
  const command='/usr/bin/curl --head --silent --show-error --max-time 15 https://example.com';
  const checks=[];
  for(const [name,decision] of [['deny','deny'],['allow-once','allow'],['deny-again','deny']]){
    const result=await x.round('network-'+name,{content:`这是新一次沙箱联网审批验收。用户明确重新要求本次调用，之前拒绝或批准均仅对之前那次生效，不要跳过。仅调用一次 Bash，command 严格为 ${command}。不要设置 dangerouslyDisableSandbox。不要在同轮重试，不要切换其他联网工具；如果本次被拒绝就报告实际拒绝并结束。`,decision,expectedTool:'Bash',expectApproval:true,validateApproval:d=>d.permission_boundary==='sandbox_network' && d.tool_input?.command===command && d.tool_input?.network_target?.host==='example.com' && d.tool_input?.network_target?.port===443});
    x.checkTool(result,'Bash',{isError:decision==='deny',...(decision==='allow'?{contains:'200'}:{})});
    const approvals=result.events.filter(e=>e.event_type==='permission_request');
    assert(approvals.every(e=>e.data.permission_boundary==='sandbox_network'));
    checks.push({name,decision,requestID:result.requestID,roundID:result.roundID,approvals:result.approvals,networkTargets:approvals.map(e=>e.data.tool_input.network_target)});
    x.save('network-approval-evidence',checks);
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
