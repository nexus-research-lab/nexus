const x=require('/tmp/nexus-app-contract.cjs');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {randomUUID}=require('node:crypto');
(async()=>{
  const target=fs.mkdtempSync('/Users/berhand/nexus-sandbox-claude-boundary-qa-');
  const checks=[];
  const prefs=await x.api('/settings/preferences');
  if(prefs.agent_runtime_kind!=='claude')await x.api('/settings/preferences','PATCH',{agent_runtime_kind:'claude'},{'If-Match':`"preferences-${prefs.version}"`});
  try {
    for(const [name,mode,allowed] of [['claude-boundary-default','default',false],['claude-boundary-full','bypassPermissions',true],['claude-boundary-return','default',false]]) {
      const file=target+'/'+name+'.txt',marker='CLAUDE_ACCESS_'+randomUUID();
      const command=`/usr/bin/ruby -e 'File.write(ARGV[0], ARGV[1])' '${file}' '${marker}'`;
      const settings=await x.settings(x.dmKey,mode),before=await x.receipt(x.dmKey);
      const result=await x.round(name,{content:`这是已授权的独立 macOS 沙箱验收目录，只包含本次测试文件。请仅调用一次 Bash，command 严格为：${command} 。不设置 dangerouslyDisableSandbox，不改写命令，不调用其他工具；若拒绝则报告实际错误后结束，不重试。`});
      x.checkTool(result,'Bash',{isError:!allowed});
      assert.equal(fs.existsSync(file),allowed);
      if(allowed)assert.equal(fs.readFileSync(file,'utf8'),marker);
      const after=await x.receipt(x.dmKey);
      assert.equal(after.receipt.runtime_kind,'claude');assert.equal(after.receipt.phase,'confirmed');
      assert.equal((after.receipt.required_capabilities||[]).includes('claude_native_sandbox'),!allowed);
      checks.push({name,mode,settings,before,after,command,fileExists:allowed,marker:allowed?marker:undefined,round:{requestID:result.requestID,roundID:result.roundID,approvals:result.approvals}});
      x.save('claude-access-evidence',checks);
      console.log(JSON.stringify({name,generation:after.receipt.generation,mode,writeAllowed:allowed,approvals:result.approvals}));
    }
  } finally {
    await x.settings(x.dmKey,'default');
    const finalPrefs=await x.api('/settings/preferences');
    if(finalPrefs.agent_runtime_kind!=='nxs')await x.api('/settings/preferences','PATCH',{agent_runtime_kind:'nxs'},{'If-Match':`"preferences-${finalPrefs.version}"`});
    for(const f of ['claude-boundary-default.txt','claude-boundary-full.txt','claude-boundary-return.txt'])if(fs.existsSync(target+'/'+f))fs.unlinkSync(target+'/'+f);
    fs.rmdirSync(target);
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
