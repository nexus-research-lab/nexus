import pathlib,json,subprocess,os,time,re,urllib.request,urllib.error,shutil
p=json.load(open('/tmp/nexus-app-reconnect-build.json'));root=pathlib.Path(p['root']);prior=pathlib.Path(p['priorRoot']);state=pathlib.Path(p['stateRoot'])
assert p['bundleID']=='com.nexus.sandbox-switch-qa'
assert state==pathlib.Path('/var/folders/jk/9xhnwgrx6cj4fj76wffmxy0w0000gn/T/nexus-macos-recovery-app-8h00d3gv/state')
for name in ['test-conversation.json','test-group.json','background-approval-evidence.json','background-final-state.json']:shutil.copy2(prior/name,root/name)
subprocess.run(['codesign','--verify','--deep','--strict',p['app']],check=True)
env={k:os.environ[k] for k in ['PATH','HOME','USER','LOGNAME','TMPDIR','LANG'] if k in os.environ};env.update(NEXUS_DESKTOP_STATE_ROOT=str(state),NEXUS_DESKTOP_PREFERENCES_SUITE=p['bundleID'],NEXUS_DESKTOP_KEYCHAIN_MODE='file',NEXUS_DESKTOP_DISABLE_UPDATE_CHECK='1')
with (root/'app-contract.log').open('ab') as log:app=subprocess.Popen([p['app']+'/Contents/MacOS/Nexus'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
p['appPID']=app.pid;pathlib.Path('/tmp/nexus-current-recovery-acceptance.json').write_text(json.dumps(p))
for _ in range(80):
 for child in subprocess.run(['pgrep','-P',str(app.pid)],capture_output=True,text=True).stdout.split():
  cmd=subprocess.run(['ps','-p',child,'-o','comm='],capture_output=True,text=True).stdout.strip()
  if cmd!=p['app']+'/Contents/MacOS/nexus-server':continue
  raw=subprocess.check_output(['ps','eww','-p',child,'-o','command='],text=True);assert 'NEXUS_STATE_ROOT='+str(state) in raw
  tok=re.search(r'NEXUS_DESKTOP_SESSION_TOKEN=([a-f0-9]{64})',raw);port=re.search(r'\bPORT=(\d+)\b',raw)
  if not tok or not port:continue
  conn={'base':'http://127.0.0.1:'+port.group(1)+'/nexus/v1','token':tok.group(1)};file=root/'test-connection.json';file.write_text(json.dumps(conn));file.chmod(0o600)
  try:
   req=urllib.request.Request(conn['base']+'/agents',headers={'X-Nexus-Desktop-Token':conn['token']});r=json.load(urllib.request.urlopen(req,timeout=2));assert r.get('code')=='0000';print(json.dumps({'appPID':app.pid,'source':p['source'],'healthy':True}));raise SystemExit(0)
  except urllib.error.URLError:pass
 time.sleep(.25)
raise RuntimeError('test App failed startup')
