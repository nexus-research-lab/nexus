const x=require('/tmp/nexus-app-contract.cjs');
const assert=require('node:assert/strict');
const {randomUUID}=require('node:crypto');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const agent=await x.api('/agents/'+x.agentID);
  const file=agent.workspace_path+'/sandbox-ui-qa.txt';
  const checks=[];
  for(const decision of ['deny','allow_once']){
    const task=await x.api('/capability/scheduled/tasks','POST',{request_id:randomUUID(),name:'Sandbox QA background '+decision,agent_id:x.agentID,schedule:{kind:'every',interval_seconds:86400,timezone:'Asia/Shanghai'},instruction:`这是独立后台任务的权限验收。请仅调用一次 mcp__nexus__deliver_files，参数固定为 {"paths":["${file}"]}。不要读取、写入、联网或调用其他工具。若权限阻塞则立即结束；得到后续批准再执行同一调用。`,execution_kind:'agent',permission_mode:'default',session_target:{kind:'isolated'},delivery:{mode:'none'},source:{kind:'user_page'},enabled:false});
    assert.equal(task.enabled,false);
    const started=await x.api(`/capability/scheduled/tasks/${task.job_id}/run`,'POST',{request_id:randomUUID(),expected_configuration_version:task.configuration_version});
    const record={decision,task,started};checks.push(record);x.save('background-approval-evidence',checks);
    let pending;
    for(let i=0;i<150;i++){
      const requests=await x.api('/capability/scheduled/permission-requests?status=pending&job_id='+task.job_id);
      pending=requests.find(r=>r.run_id===started.run_id);
      if(pending)break;
      await sleep(1000);
    }
    assert(pending,decision+': background approval was not published');
    record.pending=pending;x.save('background-approval-evidence',checks);
    assert.equal(pending.capability.tool_name,'mcp__nexus__deliver_files');
    record.resolution=await x.api('/capability/scheduled/permission-requests/'+pending.request_id+'/decision','POST',{decision,job_id:task.job_id,run_id:started.run_id,policy_revision:pending.policy_revision});
    x.save('background-approval-evidence',checks);
    let run;
    for(let i=0;i<150;i++){
      const runs=await x.api(`/capability/scheduled/tasks/${task.job_id}/runs`);
      run=runs.find(r=>r.run_id===started.run_id);
      if(run && ['succeeded','failed','cancelled'].includes(run.status))break;
      await sleep(1000);
    }
    record.finalRun=run;x.save('background-approval-evidence',checks);
    console.log(JSON.stringify({decision,jobID:task.job_id,runID:started.run_id,status:run?.status,resolution:record.resolution}));
    if(decision==='deny')assert(['failed','cancelled'].includes(run?.status));
    else assert.equal(run?.status,'succeeded');
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
