const x=require('/tmp/nexus-app-contract.cjs');
(async()=>{
  await x.settings(x.groupRuntimeKey,'default');
  const agent=await x.api('/agents/'+x.agentID);
  const file=agent.workspace_path+'/sandbox-group-qa.txt';
  const checks=[];
  for(const decision of ['deny','allow']){
    const result=await x.round('room-'+decision,{key:x.groupKey,content:`这是新一次独立群聊的审批验收。用户重新明确要求执行本轮调用；此前拒绝只对当时调用生效，不要跳过这次新请求。请只调用一次 mcp__nexus__deliver_files，把已存在的 ${file} 作为本次交付文件。不要读写任何文件，不要联网；如果本次权限被拒绝，报告拒绝并立即结束，不要在同轮重试。`,decision,expectedTool:'mcp__nexus__deliver_files',expectApproval:true,validateApproval:d=>JSON.stringify(d.tool_input).includes('sandbox-group-qa.txt')});
    x.checkTool(result,'mcp__nexus__deliver_files',{isError:decision==='deny'});
    checks.push({decision,requestID:result.requestID,roundID:result.roundID,approvals:result.approvals,receipt:await x.receipt(x.groupRuntimeKey)});
    x.save('room-approval-evidence',checks);
  }
})().catch(e=>{console.error(e.message);process.exitCode=1});
