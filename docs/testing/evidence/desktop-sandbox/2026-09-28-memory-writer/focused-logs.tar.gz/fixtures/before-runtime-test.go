//go:build darwin

// INPUT: 真实沙箱、后台记忆运行和执行中替换的控制文件/目录。
// OUTPUT: 锁和完成写入遵守文件策略；释放不误删替换文件，改名不把完成写到新目录。
// POS: 后台记忆写入协调的原生回归，模型由无网络夹具代替。
package runtime

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	delegation "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/agent"
	coresession "github.com/nexus-research-lab/nexus-agent-sdk-go/internal/session"
	"github.com/nexus-research-lab/nexus-agent-sdk-go/sandbox"
)

// TestDarwinSandboxMemoryWriter 拒绝锁 IO/完成写入，并在允许时完成整理。
func TestDarwinSandboxMemoryWriter(t *testing.T) {
	for _, scenario := range []string{"acquire_denied", "legacy_read_denied", "completion_denied", "allowed", "lock_replaced", "directory_replaced"} {
		t.Run(scenario, func(t *testing.T) {
			cfg := contextFileFixture(t)
			cfg.Session.DisablePersistence = false
			cfg.Env["NEXUS_DISABLE_AUTO_MEMORY"] = ""
			cfg.Env["NEXUS_ENABLE_AUTO_DREAM"] = "1"
			cfg.Tools.Permission.Sandbox.Resources.WriteScope = sandbox.WriteScopeWorkspaceWrite
			policy := &sandbox.FilesystemConfig{}
			cfg.Tools.Permission.Sandbox.Filesystem = policy
			memoryDir := filepath.Join(cfg.Project.CWD, "memory")
			legacy := filepath.Join(memoryDir, ".consolidation-active")
			guard := filepath.Join(memoryDir, ".consolidation-lock")
			completion := filepath.Join(memoryDir, ".consolidated-at")
			transcripts := coresession.ProjectDir(cfg.ConfigDir, cfg.Project.CWD)
			for index := range 5 {
				writeContextFixture(t, filepath.Join(transcripts, fmt.Sprintf("history-%d.jsonl", index)), "{}\n")
			}
			switch scenario {
			case "acquire_denied":
				policy.DenyWrite = []string{legacy, guard}
			case "legacy_read_denied":
				writeContextFixture(t, legacy, "99999999\n")
				policy.DenyRead = []string{legacy}
			case "completion_denied":
				policy.DenyWrite = []string{completion}
			}
			called := false
			replacedPath := ""
			replacement := fmt.Sprintf("%d\n", os.Getpid())
			stop := errors.New("stop after replacing the lock")
			cfg.Tools.Agent.Runner = func(_ context.Context, _ delegation.AgentRunRequest) (delegation.AgentRunResult, error) {
				called = true
				if scenario == "lock_replaced" {
					replacedPath = guard
					if _, err := os.Stat(guard); os.IsNotExist(err) {
						replacedPath = legacy // 修复前夹具仍验证原执行锁。
					}
					if err := os.Rename(replacedPath, replacedPath+".displaced"); err != nil {
						t.Fatal(err)
					}
					writeContextFixture(t, replacedPath, replacement)
					return delegation.AgentRunResult{}, stop
				}
				if scenario == "directory_replaced" {
					if err := os.Rename(memoryDir, memoryDir+".displaced"); err != nil {
						t.Fatal(err)
					}
					writeContextFixture(t, completion, "OTHER_OWNER_COMPLETION")
				}
				return delegation.AgentRunResult{Status: "completed"}, nil
			}
			rt, err := New(cfg)
			if err != nil {
				t.Fatal(err)
			}
			result, err := rt.TryAutoDream(t.Context())
			switch scenario {
			case "acquire_denied", "legacy_read_denied":
				if err == nil || called {
					t.Fatalf("denied lock reached maintenance: called=%t result=%#v err=%v", called, result, err)
				}
			case "completion_denied":
				if err == nil || !called || result.Status == "completed" {
					t.Fatalf("denied completion: called=%t result=%#v err=%v", called, result, err)
				}
				if _, err := os.Stat(completion); !os.IsNotExist(err) {
					t.Fatalf("denied completion was written: %v", err)
				}
			case "allowed":
				if err != nil || !called || result.Status != "completed" {
					t.Fatalf("allowed maintenance: called=%t result=%#v err=%v", called, result, err)
				}
				if _, err := os.Stat(completion); err != nil {
					t.Fatal(err)
				}
			case "lock_replaced":
				if !errors.Is(err, stop) || !called {
					t.Fatalf("replacement fixture: called=%t err=%v", called, err)
				}
				got, err := os.ReadFile(replacedPath)
				if err != nil || string(got) != replacement {
					t.Fatalf("release changed another holder: %q err=%v", got, err)
				}
			case "directory_replaced":
				if err == nil || result.Status == "completed" {
					t.Fatalf("replaced directory reported completion: %#v err=%v", result, err)
				}
				got, err := os.ReadFile(completion)
				if err != nil || string(got) != "OTHER_OWNER_COMPLETION" {
					t.Fatalf("completion changed replacement directory: %q err=%v", got, err)
				}
			}
		})
	}
}
